geosetup
========

Python package for reprojecting, gridding, and writing geospatial data to formats supported by GDAL