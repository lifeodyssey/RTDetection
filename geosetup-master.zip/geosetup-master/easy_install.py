'''
Configuration Script
'''

print "Enter the location of the files: "; directory = raw_input()

path = r"%s" % directory
